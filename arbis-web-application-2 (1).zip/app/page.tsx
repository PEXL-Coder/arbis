"use client"

import { useState } from "react"
import Sidebar from "@/components/arbis/sidebar"
import Dashboard from "@/components/arbis/dashboard"
import GuidedFlow from "@/components/arbis/guided-flow"
import KnowledgeHub from "@/components/arbis/knowledge-hub"
import Complaints from "@/components/arbis/complaints"
import VCAssistant from "@/components/arbis/vc-assistant"
import VerbatimAnalyzer from "@/components/arbis/verbatim-analyzer"
import ArbyChatbot from "@/components/arbis/arby-chatbot"

export default function Page() {
  const [activeView, setActiveView] = useState("dashboard")
  const [navigationData, setNavigationData] = useState<any>(null)

  const handleNavigate = (view: string, data?: any) => {
    setActiveView(view)
    setNavigationData(data || null)
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeView={activeView} onNavigate={(view) => handleNavigate(view)} />
      <main className="flex-1 overflow-auto">
        {activeView === "dashboard" && <Dashboard onNavigate={handleNavigate} />}
        {activeView === "guided-flow" && <GuidedFlow initialStepId={navigationData?.stepId} />}
        {activeView === "knowledge-hub" && <KnowledgeHub initialArticleId={navigationData?.articleId} />}
        {activeView === "complaints" && <Complaints />}
        {activeView === "vc-assistant" && <VCAssistant />}
        {activeView === "verbatim-analyzer" && <VerbatimAnalyzer />}
      </main>
      <ArbyChatbot onNavigate={handleNavigate} />
    </div>
  )
}

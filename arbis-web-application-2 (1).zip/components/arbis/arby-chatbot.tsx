"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import styles from "./arby-chatbot.module.css"
import { knowledgeArticles, flowSteps } from "./guided-flow-data"

interface Message {
  id: number
  type: "user" | "bot"
  content: string
  timestamp: Date
  actions?: ChatAction[]
  articles?: typeof knowledgeArticles
}

interface ChatAction {
  label: string
  action: string
  data?: any
}

interface ArbyChatbotProps {
  onNavigate: (view: string, data?: any) => void
}


const intentPatterns = {
  // Greetings (English + Multilingual)
  greeting: /^(hi|hello|hey|hiya|yo|sup|greetings|what's up|how are you|howdy|morning|evening|hi there|hello there|good morning|good afternoon|good evening|long time no see|nice to meet you|hey there|hey buddy|hey friend|hola|bonjour|salut|ciao|namaste|hallo|ola|konnichiwa|ni hao)/i,

  // Help / Assistance
  help: /(help|assist|support|what can you do|how do you work|need help|can you help me|help me out|show me how|guide me|instructions|how to use|how does this work|explain features|show options|help menu|how do i start|what are your features|how do i begin|teach me|show guide|help please|need assistance|help me understand)/i,

  // Navigation
  navigation: {
    dashboard: /(dashboard|home|main|overview|metrics|landing page|start page|summary|homepage|main screen|go home|open dashboard|show dashboard)/i,
    guidedFlow: /(guided flow|call flow|flow|call script|script|process|steps|workflow|guided steps|call process|open flow|start flow|show flow)/i,
    knowledgeHub: /(knowledge|hub|browse articles|all articles|knowledge base|kb|documentation|info center|help center|resource center|open knowledge hub|show knowledge hub)/i,
    verbatimAnalyzer: /(verbatim|analyzer|sentiment|analyse|analyze|transcript|survey|feedback|text analysis|comments|verbatim tool|open analyzer|show analyzer)/i,
    complaints: /(complaint|complain|escalate|escalation|issue|problem|raise complaint|report issue|file complaint|submit complaint|open complaints|show complaints)/i,
    vcAssistant: /(vc assistant|vulnerability assistant|vc tool|vulnerability checker|vc support|open vc assistant|show vc assistant)/i,
  },

  // Step Navigation
  stepNavigation: /(?:go to|take me to|show|open|navigate to|jump to|move to|switch to|start step|next step|previous step|step number)\s*step\s*(\d+)/i,

  // Vulnerability Detection (Expanded)
  vulnerabilityQuestion:
    /(can('?t| not) afford|financial difficult|struggling to pay|money problem|is that a vc|is this a vc|vulnerable customer|vulnerability indicator|could this be|mental health|bereavement|bereaved|passed away|died|death|suicide|self.?harm|disability|disabled|illness|cancer|terminal|elderly|confused|dementia|alzheimer|addiction|gambling|domestic|abuse|violence|hardship|debt|bankrupt|homeless|poverty|low income|lost job|unemployed|stress|anxiety|depression|trauma|grief|struggling financially|financial hardship|mental breakdown|panic attack|overwhelmed|lonely|isolation|bereft)/i,

  // Article Search
  articleSearch: /(show|find|get|search|article|articles|look up|lookup|pull up|display|fetch|give me|show me|find info|search for)\s*(about|on|for|regarding|related to)?\s*(.+)/i,

  // Topic Search (Expanded)
  topicSearch: {
    claims: /(claim|claims|accident|incident|damage|theft|windscreen|fnol|first notification|report claim|file claim|submit claim|insurance claim|start claim|claim process)/i,
    cancellation: /(cancel|cancellation|cooling off|terminate|end policy|stop policy|close account|policy cancellation|cancel my policy|end my policy)/i,
    renewal: /(renew|renewal|renewing|auto.?renew|policy renewal|extend policy|continue policy|renew my policy|renew insurance)/i,
    mta: /(mta|mid-term|change|amendment|update policy|modify|change address|change vehicle|policy update|edit policy|make changes|update details)/i,
    payment: /(payment|pay|premium|installment|instalment|direct debit|card|missed payment|failed payment|billing|invoice|make payment|pay bill|payment issue|payment options)/i,
    ncd: /(ncd|no claims|bonus|discount|proof of ncd|protected|no claims discount|bonus protection|ncd proof|ncd certificate)/i,
    documents: /(document|documents|certificate|proof|schedule|policy document|download document|get document|view documents|send me documents|policy papers)/i,
    cover: /(cover|coverage|policy details|what am i covered|protected|comprehensive|third party|insurance cover|coverage details|what does my policy cover|cover options)/i,
    idv: /(id&amp;v|identity|verification|security|data protection|gdpr|dpa|identity check|verify identity|id verification|identity proof)/i,
    vulnerability: /(vulnerable|vulnerability|vc|mental health|bereavement|financial hardship|support|special needs|extra help|vc indicator|vulnerability support)/i,
  },

  // Thanks & Goodbye
  thanks: /(thank|thanks|cheers|appreciate|thank you|much obliged|grateful|thanks a lot|thanks so much|many thanks|thank you very much|thanks buddy|thanks friend)/i,
  goodbye: /(bye|goodbye|see you|later|exit|close|farewell|catch you later|talk soon|end chat|quit|leave|see ya|take care)/i,

  // Extra Intents
  smallTalk: /(how are you|what's up|how's it going|how do you do|what are you doing|tell me something|chat with me|talk to me|just chatting|how's your day|what's new|what's happening)/i,
  affirmation: /(yes|yeah|yep|sure|ok|okay|alright|affirmative|correct|right|sounds good|fine|absolutely|of course|definitely|sure thing)/i,
  negation: /(no|nope|nah|not really|negative|don't|do not|never|not now|no thanks|not today)/i,
  confusion: /(don't understand|confused|what do you mean|explain|clarify|not clear|lost|help me understand|please explain|what does that mean)/i,
  feedback: /(good job|well done|great|awesome|amazing|bad|poor|terrible|needs improvement|excellent|fantastic|brilliant|horrible|love it|hate it)/i,

  // Troubleshooting
  troubleshooting: /(error|issue|problem|bug|not working|broken|fix|repair|troubleshoot|technical issue|system down|app not working|crash|freeze|glitch|system error)/i,

  // Account & Profile
  account: /(account|profile|login|sign in|sign out|log out|update account|change password|reset password|account settings|manage account|update details|edit profile)/i,

  // Scheduling
  scheduling: /(schedule|appointment|book|meeting|set reminder|remind me|calendar|plan|arrange|schedule call|book slot|set up meeting)/i,

  // General Questions
  generalQuestion: /(what is|how to|why|where|when|who|tell me|explain|define|meaning of|give me info|details about|what does|how do i)/i,

  // New Categories
  greetingsOtherLang: /(hola|bonjour|salut|ciao|namaste|hallo|ola|konnichiwa|ni hao|shalom|merhaba)/i,
  jokes: /(tell me a joke|make me laugh|funny|joke|say something funny)/i,
  weather: /(weather|forecast|temperature|rain|sunny|cloudy|storm|snow|hot|cold)/i,
  timeDate: /(time|date|day|today|tomorrow|current time|what time is it|what day is it)/i,
  botInfo: /(who are you|what is your name|about you|your purpose|what do you do|tell me about yourself)/i,
  greetingsCasual: /(yo|sup|hey man|hey girl|hey dude|hey bro|hey sis)/i,
};



const vulnerabilityIndicators = {
  financial: {
    keywords: [
      "can't afford", "cannot afford", "struggling to pay", "financial difficulty", "money problems",
      "debt", "bankrupt", "homeless", "benefits", "unemployed", "redundant", "low income", "poverty",
      "lost job", "job loss", "income reduced", "financial hardship", "can't make payment", "missed payment",
      "payment overdue", "arrears", "behind on payments", "credit issues", "loan default", "repossession",
      "bailiff", "court order", "struggling financially", "cost of living", "can't manage bills"
    ],
    response: `**Financial Hardship Vulnerability Detected**

**Indicators:**
• Mentions inability to pay or financial stress
• References to unemployment or reduced income
• Mentions of debt or bankruptcy

**Recommended Actions:**
1. Show empathy: "I understand this must be a difficult time for you"
2. Ask if there are other circumstances affecting them
3. Explore payment options (payment plans, deferrals)
4. Offer specialist financial support or signpost to charities
5. Document the vulnerability in notes

**Important:** FCA recognizes financial hardship as a vulnerability. Handle with care.`,
  },

  bereavement: {
    keywords: [
      "passed away", "died", "death", "deceased", "bereavement", "bereaved", "lost", "funeral",
      "mourning", "grief", "condolence", "widow", "widower", "orphan", "loss of loved one"
    ],
    response: `**Bereavement Vulnerability Detected**

**Recommended Actions:**
1. Express condolences: "I'm so sorry for your loss"
2. Offer to handle everything in one call to reduce stress
3. Provide clear next steps in writing
4. Flag account for sensitive handling
5. Consider follow-up support

**Important:** Bereaved customers may struggle to process information. Speak slowly and repeat if needed.`,
  },

  mentalHealth: {
    keywords: [
      "mental health", "depression", "anxiety", "stressed", "suicide", "self-harm", "breakdown",
      "overwhelmed", "can't cope", "panic attack", "trauma", "grief", "emotional distress",
      "mental illness", "psychological", "burnout", "nervous breakdown"
    ],
    response: `**Mental Health Vulnerability Detected**

**Immediate Actions:**
1. If suicide/self-harm mentioned, follow safeguarding protocol immediately
2. Show understanding: "I can hear this is really difficult for you"
3. Ask if they have support around them
4. Offer to take things slowly
5. Consider specialist handler involvement

**Warning Signs to Escalate:**
• Mentions of self-harm or suicide
• Extreme distress or inability to communicate

**Important:** Document carefully and escalate safeguarding concerns.`,
  },

  ageRelated: {
    keywords: [
      "elderly", "confused", "dementia", "alzheimer", "can't remember", "hard of hearing",
      "memory problems", "senior", "old age", "frail", "forgetful", "age-related", "cognitive decline"
    ],
    response: `**Age-Related or Cognitive Vulnerability Detected**

**Recommended Actions:**
1. Speak clearly and slowly
2. Offer to repeat information
3. Check understanding at each stage
4. Ask if someone can assist them
5. Provide written confirmation if helpful

**Important:** Consider decision-making capacity. Offer support where needed.`,
  },

  disability: {
    keywords: [
      "disability", "disabled", "illness", "cancer", "terminal", "chronic", "hospital", "treatment",
      "wheelchair", "visual impairment", "hearing impairment", "speech difficulty", "mobility issues",
      "long-term condition", "health condition", "physical impairment"
    ],
    response: `**Health/Disability Vulnerability Detected**

**Recommended Actions:**
1. Show empathy for their situation
2. Ask if they need adjustments in communication
3. Offer flexibility in handling their policy
4. Document reasonable adjustments

**Important:** Ensure compliance with Equality Act and FCA guidelines.`,
  },

  addiction: {
    keywords: [
      "addiction", "gambling", "alcohol", "drugs", "substance abuse", "dependency", "rehab",
      "drug problem", "alcoholic", "gambling habit", "compulsive gambling"
    ],
    response: `**Addiction-Related Vulnerability Detected**

**Recommended Actions:**
1. Show empathy and avoid judgmental language
2. Ask if they need extra time or support
3. Offer specialist referral if available
4. Document carefully

**Important:** Addiction can impact decision-making and financial stability.`,
  },

  domesticAbuse: {
    keywords: [
      "domestic abuse", "violence", "abuse", "threatened", "unsafe", "fear", "coercion",
      "controlling partner", "physical abuse", "emotional abuse", "sexual abuse", "intimidation"
    ],
    response: `**Domestic Abuse Vulnerability Detected**

**Immediate Actions:**
1. Prioritize safety: Do not disclose sensitive info if others are present
2. Speak calmly and offer reassurance
3. Provide details of specialist support services
4. Document carefully and escalate if needed

**Important:** Handle with extreme sensitivity and confidentiality.`,
  },

  languageBarrier: {
    keywords: [
      "don't speak English", "language barrier", "can't understand", "translator", "interpreter",
      "communication difficulty", "foreign language", "non-native speaker"
    ],
    response: `**Language Barrier Vulnerability Detected**

**Recommended Actions:**
1. Speak slowly and clearly
2. Offer translation or interpreter services
3. Confirm understanding at each step
4. Provide written information if possible

**Important:** Miscommunication can lead to errors. Ensure clarity.`,
  },

  technologyBarrier: {
    keywords: [
      "can't use computer", "don't understand technology", "struggling with app", "not tech-savvy",
      "can't access online", "digital exclusion", "no internet", "no smartphone"
    ],
    response: `**Technology Barrier Vulnerability Detected**

**Recommended Actions:**
1. Offer alternative channels (phone, paper)
2. Provide step-by-step guidance
3. Be patient and avoid jargon
4. Document preferred communication method

**Important:** Digital exclusion is a recognized vulnerability.`,
  },
};



const quickSuggestions = [
  { label: "Claims Articles", action: "search", data: { topic: "claims" } },
  { label: "Cancellation", action: "search", data: { topic: "cancellation" } },
  { label: "Payment Issues", action: "search", data: { topic: "payment" } },
  { label: "Vulnerability Help", action: "search", data: { topic: "vulnerability" } },
  { label: "Guided Flow", action: "navigate", data: { view: "guided-flow" } },
]

export default function ArbyChatbot({ onNavigate }: ArbyChatbotProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [selectedArticle, setSelectedArticle] = useState<(typeof knowledgeArticles)[0] | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (messages.length === 0) {
      const savedHistory = localStorage.getItem("arby_chat_history")
      if (savedHistory) {
        try {
          const parsed = JSON.parse(savedHistory)
          setMessages(parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })))
        } catch {
          addBotMessage(getGreeting())
        }
      } else {
        addBotMessage(getGreeting())
      }
    }
  }, [])

  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("arby_chat_history", JSON.stringify(messages.slice(-50)))
    }
  }, [messages])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen])

  const getGreeting = (): string => {
    const hour = new Date().getHours()
    let timeGreeting = "Hello"
    if (hour < 12) timeGreeting = "Good morning"
    else if (hour < 17) timeGreeting = "Good afternoon"
    else timeGreeting = "Good evening"

    // Multiple dynamic greeting options
    const greetings = [
      `${timeGreeting}! I'm ARBY, your ARBIS assistant. I can help you:\n\n• Find articles on claims, cancellations, payments\n• Navigate to any step in the Guided Flow\n• Answer questions about vulnerable customers\n• Open the Verbatim Analyzer\n\nTry asking "Show me claims articles" or "Is financial hardship a VC?"`,

      `${timeGreeting}! ARBY here 👋. I’m ready to guide you through:\n\n• Claims, cancellations, and payments\n• Any step in the Guided Flow\n• Vulnerability questions\n• Verbatim Analyzer\n\nYou could start with "Open guided flow" or "Show me payment articles".`,

      `${timeGreeting}! Welcome back to ARBY. I can:\n\n• Pull up knowledge articles\n• Walk you through guided steps\n• Help with vulnerable customer queries\n• Launch the Verbatim Analyzer\n\nFor example, try "Go to step 3" or "Search cancellation articles".`,

      `${timeGreeting}! I’m ARBY, your assistant for ARBIS. Here’s what I can do:\n\n• Find and display articles\n• Navigate guided flows\n• Provide vulnerability guidance\n• Open analysis tools\n\nQuick tip: Ask "Show me claims articles" to get started fast!`,
    ]

    // Pick one at random
    const randomIndex = Math.floor(Math.random() * greetings.length)
    return greetings[randomIndex]
  }


  const addBotMessage = useCallback((content: string, actions?: ChatAction[], articles?: typeof knowledgeArticles) => {
    const message: Message = {
      id: Date.now(),
      type: "bot",
      content,
      timestamp: new Date(),
      actions,
      articles,
    }
    setMessages((prev) => [...prev, message])
  }, [])

  const addUserMessage = useCallback((content: string) => {
    const message: Message = {
      id: Date.now(),
      type: "user",
      content,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, message])
  }, [])

  const processQuery = useCallback((query: string) => {
  const lowerQuery = query.toLowerCase().trim()

  // --- Special case: Step navigation ---
  const stepMatch = lowerQuery.match(intentPatterns.stepNavigation)
  if (stepMatch) {
    const stepNum = Number.parseInt(stepMatch[1])
    const step = flowSteps.find((s) => s.id === stepNum)
    if (step) {
      return {
        response: `Opening **Step ${stepNum}: ${step.title}**\n\nThis step covers: "${step.question}"`,
        actions: [{ label: `Go to Step ${stepNum}`, action: "navigateStep", data: { stepId: stepNum } }],
      }
    }
    return {
      response: `Step ${stepNum} not found. Available steps: 0-30.`,
      actions: [{ label: "Open Guided Flow", action: "navigate", data: { view: "guided-flow" } }],
    }
  }

  // --- Special case: Vulnerability detection ---
  if (intentPatterns.vulnerabilityQuestion.test(lowerQuery)) {
    for (const [type, data] of Object.entries(vulnerabilityIndicators)) {
      if (data.keywords.some((kw) => lowerQuery.includes(kw))) {
        return {
          response: data.response,
          actions: [
            { label: "VC Assistant", action: "navigate", data: { view: "vc-assistant" } },
            { label: "Vulnerability Articles", action: "search", data: { topic: "vulnerability" } },
          ],
        }
      }
    }
    return {
      response: `This could potentially indicate a **Vulnerable Customer**.\n\nAlways show empathy, ask about circumstances, document indicators, and offer support.`,
      actions: [
        { label: "Open VC Assistant", action: "navigate", data: { view: "vc-assistant" } },
        { label: "Vulnerability Articles", action: "search", data: { topic: "vulnerability" } },
      ],
    }
  }

  // --- General intent pattern loop ---
  for (const [intent, pattern] of Object.entries(intentPatterns)) {
    if (typeof pattern === "object" && !(pattern instanceof RegExp)) {
      // Nested patterns (navigation, topicSearch)
      for (const [subIntent, subPattern] of Object.entries(pattern)) {
        if (subPattern.test(lowerQuery)) {
          if (intent === "navigation") {
            const viewMap: Record<string, string> = {
              dashboard: "dashboard",
              guidedFlow: "guided-flow",
              knowledgeHub: "knowledge-hub",
              verbatimAnalyzer: "verbatim-analyzer",
              complaints: "complaints",
              vcAssistant: "vc-assistant",
            }
            const viewName = viewMap[subIntent]
            return {
              response: `Opening ${subIntent}...`,
              actions: [{ label: `Go to ${subIntent}`, action: "navigate", data: { view: viewName } }],
            }
          }
          if (intent === "topicSearch") {
            const relatedArticles = knowledgeArticles.filter(
              (a) =>
                a.title.toLowerCase().includes(subIntent) ||
                a.content.toLowerCase().includes(subIntent) ||
                a.category.toLowerCase().includes(subIntent),
            )
            if (relatedArticles.length > 0) {
              return {
                response: `Found **${relatedArticles.length} article(s)** about ${subIntent}:`,
                articles: relatedArticles.slice(0, 5),
                actions:
                  relatedArticles.length > 5
                    ? [{ label: "View All in Knowledge Hub", action: "navigate", data: { view: "knowledge-hub" } }]
                    : undefined,
              }
            }
          }
        }
      }
    } else if ((pattern as RegExp).test(lowerQuery)) {
      // Simple regex patterns
      switch (intent) {
        case "greeting":
          return {
            response: getGreeting(),
            actions: [
              { label: "Claims Articles", action: "search", data: { topic: "claims" } },
              { label: "Guided Flow", action: "navigate", data: { view: "guided-flow" } },
            ],
          }
        case "help":
          return { response: "I can help you with articles, navigation, VC questions, and verbatim analysis." }
        case "thanks":
          return { response: "You're welcome! Is there anything else I can help you with?" }
        case "goodbye":
          return { response: "Goodbye! Feel free to chat anytime." }
        case "jokes":
          return { response: "Here’s a joke: Why don’t skeletons fight each other? They don’t have the guts!" }
        case "weather":
          return { response: "I can’t fetch live weather, but you can check your local forecast online." }
        case "botInfo":
          return { response: "I’m ARBY, your ARBIS assistant. I help with articles, guided flows, and vulnerability support." }
        // Add other simple intents here...
      }
    }
  }

  // --- General article search ---
  const searchTerms = lowerQuery.replace(/(show|find|get|search|me|article|articles|about|on|for|regarding|related|to|the)/gi, "").trim()
  if (searchTerms.length > 2) {
    const matchedArticles = knowledgeArticles.filter(
      (a) =>
        a.title.toLowerCase().includes(searchTerms) ||
        a.content.toLowerCase().includes(searchTerms) ||
        a.category.toLowerCase().includes(searchTerms),
    )
    if (matchedArticles.length > 0) {
      return {
        response: `Found **${matchedArticles.length} article(s)** matching "${searchTerms}":`,
        articles: matchedArticles.slice(0, 5),
        actions:
          matchedArticles.length > 5
            ? [{ label: "Browse All Articles", action: "navigate", data: { view: "knowledge-hub" } }]
            : undefined,
      }
    }
  }

  // --- Fallback ---
  return {
    response: `I'm not sure what you're looking for. Try:\n\n• "Show me claims articles"\n• "Is can't afford a VC?"\n• "Go to step 5"\n• "Open verbatim analyzer"`,
    actions: [
      { label: "Claims Articles", action: "search", data: { topic: "claims" } },
      { label: "Guided Flow", action: "navigate", data: { view: "guided-flow" } },
    ],
  }
}, [])


  const handleSend = useCallback(() => {
    if (!inputValue.trim()) return

    const query = inputValue.trim()
    setInputValue("")
    addUserMessage(query)

    // Process immediately without delay
    setIsTyping(true)

    // Use requestAnimationFrame for minimal visual feedback then respond
    requestAnimationFrame(() => {
      setTimeout(() => {
        const result = processQuery(query)
        addBotMessage(result.response, result.actions, result.articles)
        setIsTyping(false)
      }, 150) // Minimal delay just for visual feedback
    })
  }, [inputValue, addUserMessage, addBotMessage, processQuery])

  const handleAction = useCallback(
    (action: ChatAction) => {
      switch (action.action) {
        case "navigate":
          onNavigate(action.data.view, action.data)
          addBotMessage(`Navigating to ${action.data.view.replace(/-/g, " ")}...`)
          break
        case "navigateStep":
          onNavigate("guided-flow", { stepId: action.data.stepId })
          addBotMessage(`Opening Guided Flow at Step ${action.data.stepId}...`)
          break
        case "showArticle":
          const article = knowledgeArticles.find((a) => a.id === action.data.articleId)
          if (article) setSelectedArticle(article)
          break
        case "search":
          const result = processQuery(`show me ${action.data.topic} articles`)
          addBotMessage(result.response, result.actions, result.articles)
          break
        case "clear":
          setMessages([])
          localStorage.removeItem("arby_chat_history")
          setTimeout(() => addBotMessage(getGreeting()), 100)
          break
        case "close":
          setIsOpen(false)
          break
      }
    },
    [onNavigate, addBotMessage, processQuery],
  )

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault()
        handleSend()
      }
    },
    [handleSend],
  )

  const formatMessage = (content: string) => {
    return content.split("\n").map((line, i) => {
      const formattedLine = line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      return (
        <span key={i}>
          <span dangerouslySetInnerHTML={{ __html: formattedLine }} />
          {i < content.split("\n").length - 1 && <br />}
        </span>
      )
    })
  }

  return (
    <>
      {/* Floating Button */}
      <button
        className={`${styles.floatingButton} ${isOpen ? styles.hidden : ""}`}
        onClick={() => setIsOpen(true)}
        aria-label="Open ARBY Chat"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
        <span className={styles.buttonLabel}>ARBY</span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className={styles.chatWindow}>
          <div className={styles.chatHeader}>

            <div className={styles.headerInfo}>

              <div className={styles.avatar}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M8 14s1.5 2 4 2 4-2 4-2" />
                  <line x1="9" y1="9" x2="9.01" y2="9" />
                  <line x1="15" y1="9" x2="15.01" y2="9" />
                </svg>
              </div>

              <div>
                <h3 className={styles.headerTitle}>ARBY</h3>
                <span className={styles.headerStatus}>ARBIS Assistant</span>
              </div>

            </div>
            
            <button className={styles.closeButton} onClick={() => setIsOpen(false)} aria-label="Close chat">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
            
          </div>

          <div className={styles.messagesContainer}>
            {messages.map((message) => (
              <div
                key={message.id}
                className={`${styles.message} ${message.type === "user" ? styles.userMessage : styles.botMessage}`}
              >
                <div className={styles.messageContent}>{formatMessage(message.content)}</div>

                {message.articles && message.articles.length > 0 && (
                  <div className={styles.articleList}>
                    {message.articles.map((article) => (
                      <button
                        key={article.id}
                        className={styles.articleItem}
                        onClick={() => setSelectedArticle(article)}
                      >
                        <span className={styles.articleTitle}>{article.title}</span>
                        <span className={styles.articleCategory}>{article.category}</span>
                      </button>
                    ))}
                  </div>
                )}

                {message.actions && message.actions.length > 0 && (
                  <div className={styles.messageActions}>
                    {message.actions.map((action, idx) => (
                      <button key={idx} className={styles.actionButton} onClick={() => handleAction(action)}>
                        {action.label}
                      </button>
                    ))}
                  </div>
                )}
                <span className={styles.messageTime}>
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            ))}
            {isTyping && (
              <div className={`${styles.message} ${styles.botMessage}`}>
                <div className={styles.typingIndicator}>
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className={styles.quickSuggestions}>
            {quickSuggestions.map((suggestion, idx) => (
              <button
                key={idx}
                className={styles.suggestionButton}
                onClick={() =>
                  handleAction({ label: suggestion.label, action: suggestion.action, data: suggestion.data })
                }
              >
                {suggestion.label}
              </button>
            ))}
          </div>

          <div className={styles.inputContainer}>
            <input
              ref={inputRef}
              type="text"
              className={styles.input}
              placeholder="Ask ARBY anything..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <button className={styles.sendButton} onClick={handleSend} disabled={!inputValue.trim()}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Article Modal - 80vh x 80vw centered */}
      {selectedArticle && (
        <div className={styles.modal} onClick={() => setSelectedArticle(null)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>{selectedArticle.title}</h2>
              <button className={styles.modalCloseBtn} onClick={() => setSelectedArticle(null)}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <div className={styles.modalCategory}>Category: {selectedArticle.category}</div>
            <div className={styles.modalBody}>
              <p>{selectedArticle.content}</p>
              {selectedArticle.steps && selectedArticle.steps.length > 0 && (
                <div className={styles.modalSteps}>
                  <h4>Procedure / Steps:</h4>
                  <ol>
                    {selectedArticle.steps.map((step, idx) => (
                      <li key={idx}>{step}</li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
            <div className={styles.modalActions}>
              <button
                className={styles.modalActionBtn}
                onClick={() => {
                  onNavigate("knowledge-hub", { articleId: selectedArticle.id })
                  setSelectedArticle(null)
                }}
              >
                Open in Knowledge Hub
              </button>
              <button className={styles.modalCloseButton} onClick={() => setSelectedArticle(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

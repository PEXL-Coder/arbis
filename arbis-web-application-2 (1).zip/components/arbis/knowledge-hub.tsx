"use client"

import { useState, useEffect } from "react"
import styles from "./knowledge-hub.module.css"
import { knowledgeArticles } from "./guided-flow-data"

interface KnowledgeHubProps {
  initialArticleId?: number
}

export default function KnowledgeHub({ initialArticleId }: KnowledgeHubProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All Categories")
  const [selectedArticle, setSelectedArticle] = useState<number | null>(null)

  useEffect(() => {
    if (initialArticleId !== undefined) {
      setSelectedArticle(initialArticleId)
    }
  }, [initialArticleId])

  const categories = ["All Categories", ...new Set(knowledgeArticles.map((a) => a.category))]

  const filteredArticles = knowledgeArticles.filter((article) => {
    const matchesCategory = selectedCategory === "All Categories" || article.category === selectedCategory
    const matchesSearch =
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.content.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const handleClear = () => {
    setSearchTerm("")
    setSelectedCategory("All Categories")
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Knowledge Portal</h1>
      </div>

      <div className={styles.filters}>
        <select
          className={styles.categorySelect}
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>

        <input
          type="text"
          className={styles.searchInput}
          placeholder="Search articles..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <button className={styles.clearButton} onClick={handleClear}>
          Clear
        </button>
      </div>

      <div className={styles.resultsHeader}>
        <h2 className={styles.resultsTitle}>Available Articles</h2>
        <p className={styles.resultsCount}>
          Showing {filteredArticles.length} of {knowledgeArticles.length} articles
        </p>
      </div>

      <div className={styles.articleGrid}>
        {filteredArticles.map((article) => (
          <div
            key={article.id}
            className={styles.articleCard}
            onClick={() => setSelectedArticle(article.id)}
            style={{ cursor: "pointer" }}
          >
            <div className={styles.articleCategory}>{article.category}</div>
            <h3 className={styles.articleTitle}>{article.title}</h3>
            <p className={styles.articleContent}>{article.content.substring(0, 150)}...</p>
            <span style={{ color: "var(--arbis-blue)", fontSize: "0.875rem", fontWeight: 600 }}>
              View Full Article →
            </span>
          </div>
        ))}
      </div>

      {filteredArticles.length === 0 && (
        <div className={styles.emptyState}>No articles found matching your search criteria.</div>
      )}

      {selectedArticle !== null && (
        <div className={styles.modal} onClick={() => setSelectedArticle(null)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            {(() => {
              const article = knowledgeArticles.find((a) => a.id === selectedArticle)
              if (!article) return null
              return (
                <>
                  <h2 className={styles.modalTitle}>{article.title}</h2>
                  <div className={styles.modalCategory}>Category: {article.category}</div>
                  <div className={styles.modalBody}>
                    <p>{article.content}</p>
                    {article.steps && article.steps.length > 0 && (
                      <div className={styles.modalSteps}>
                        <h4>Steps / Procedures:</h4>
                        <ol>
                          {article.steps.map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>
                    )}
                  </div>
                  <button className={styles.modalClose} onClick={() => setSelectedArticle(null)}>
                    Close Article
                  </button>
                </>
              )
            })()}
          </div>
        </div>
      )}
    </div>
  )
}

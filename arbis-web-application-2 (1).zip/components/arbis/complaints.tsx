"use client"

import { useState } from "react"
import styles from "./complaints.module.css"

interface ComplaintNode {
  id: string
  question: string
  options: Array<{ label: string; next: string | null; action?: string }>
}

const complaintTree: Record<string, ComplaintNode> = {
  start: {
    id: "start",
    question: "What type of complaint is this?",
    options: [
      { label: "Service Quality", next: "service" },
      { label: "Product Issue", next: "product" },
      { label: "Billing Dispute", next: "billing" },
      { label: "Communication Issue", next: "communication" },
    ],
  },
  service: {
    id: "service",
    question: "Please describe the service issue:",
    options: [
      { label: "Long wait times", next: "service_wait" },
      { label: "Unprofessional behavior", next: "service_behavior" },
      { label: "Incorrect information provided", next: "service_info" },
      { label: "Other service issue", next: "service_other" },
    ],
  },
  service_wait: {
    id: "service_wait",
    question: "How long did you wait?",
    options: [
      { label: "Less than 10 minutes", next: null, action: "Log complaint: Minor wait time issue" },
      {
        label: "10-30 minutes",
        next: null,
        action: "Log complaint: Moderate wait time issue. Escalate to supervisor.",
      },
      {
        label: "Over 30 minutes",
        next: null,
        action: "Log complaint: Severe wait time issue. Immediate escalation required.",
      },
    ],
  },
  service_behavior: {
    id: "service_behavior",
    question: "What type of behavior was experienced?",
    options: [
      {
        label: "Rude or dismissive",
        next: null,
        action: "Log complaint: Rude behavior. Escalate to quality assurance.",
      },
      {
        label: "Unprofessional language",
        next: null,
        action: "Log complaint: Unprofessional language. Immediate escalation and investigation required.",
      },
      {
        label: "Lack of empathy",
        next: null,
        action: "Log complaint: Lack of empathy. Schedule coaching session for agent.",
      },
    ],
  },
  product: {
    id: "product",
    question: "What is the product issue?",
    options: [
      {
        label: "Defective product",
        next: null,
        action: "Log complaint: Defective product. Initiate return/replacement process.",
      },
      {
        label: "Missing features",
        next: null,
        action: "Log complaint: Missing features. Verify product specifications and provide clarification.",
      },
      {
        label: "Product not as described",
        next: null,
        action: "Log complaint: Product mismatch. Offer refund or replacement options.",
      },
    ],
  },
  billing: {
    id: "billing",
    question: "What is the billing issue?",
    options: [
      {
        label: "Incorrect charge",
        next: null,
        action: "Log complaint: Incorrect billing. Review account and process refund if applicable.",
      },
      {
        label: "Duplicate charge",
        next: null,
        action: "Log complaint: Duplicate charge. Verify transaction and process immediate refund.",
      },
      {
        label: "Unclear billing statement",
        next: null,
        action: "Log complaint: Billing confusion. Provide detailed explanation of charges.",
      },
    ],
  },
  communication: {
    id: "communication",
    question: "What communication issue occurred?",
    options: [
      {
        label: "No response to inquiry",
        next: null,
        action: "Log complaint: No response. Follow up on original inquiry immediately.",
      },
      {
        label: "Conflicting information",
        next: null,
        action: "Log complaint: Conflicting info. Clarify correct information and apologize for confusion.",
      },
      {
        label: "Difficulty reaching support",
        next: null,
        action: "Log complaint: Access issues. Provide direct contact options and callback.",
      },
    ],
  },
}

export default function Complaints() {
  const [currentNode, setCurrentNode] = useState<string>("start")
  const [path, setPath] = useState<string[]>(["start"])
  const [resolution, setResolution] = useState<string | null>(null)

  const node = complaintTree[currentNode]

  const handleOption = (next: string | null, action?: string) => {
    if (next) {
      setCurrentNode(next)
      setPath([...path, next])
    } else if (action) {
      setResolution(action)
    }
  }

  const handleReset = () => {
    setCurrentNode("start")
    setPath(["start"])
    setResolution(null)
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Complaints Assistant</h1>
        <p className={styles.subtitle}>Guided assessment workflow for handling customer complaints effectively</p>
      </div>

      {!resolution ? (
        <div className={styles.assessmentCard}>
          <div className={styles.pathIndicator}>
            {path.map((nodeId, index) => (
              <span key={index} className={styles.pathItem}>
                {complaintTree[nodeId].question}
                {index < path.length - 1 && " → "}
              </span>
            ))}
          </div>

          <h2 className={styles.question}>{node.question}</h2>

          <div className={styles.optionsGrid}>
            {node.options.map((option, index) => (
              <button
                key={index}
                className={styles.optionButton}
                onClick={() => handleOption(option.next, option.action)}
              >
                {option.label}
              </button>
            ))}
          </div>

          {path.length > 1 && (
            <button className={styles.resetButton} onClick={handleReset}>
              Start New Assessment
            </button>
          )}
        </div>
      ) : (
        <div className={styles.resolutionCard}>
          <h2 className={styles.resolutionTitle}>Recommended Action</h2>
          <p className={styles.resolutionText}>{resolution}</p>
          <button className={styles.resetButton} onClick={handleReset}>
            Start New Assessment
          </button>
        </div>
      )}
    </div>
  )
}

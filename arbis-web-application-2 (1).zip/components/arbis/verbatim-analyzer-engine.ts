export interface PhraseAnalysis {
  text: string
  sentiment: "positive" | "negative" | "neutral"
  keywords: string[]
  score: number
  coaching?: string
}

export interface VulnerabilityIndicator {
  type: string
  phrase: string
  severity: "high" | "medium" | "low"
}

export interface ComplaintIndicator {
  type: string
  phrase: string
  shouldLog: boolean
}

export interface SentimentAnalysis {
  overallSentiment: "positive" | "negative" | "neutral"
  scores: {
    positive: number
    neutral: number
    negative: number
  }
  phrases: PhraseAnalysis[]
  themes: string[]
  coaching: string[]
  vulnerabilities: VulnerabilityIndicator[]
  complaints: ComplaintIndicator[]
  analysisType: "survey" | "transcript"
}

const SENTIMENT_KEYWORDS = {
  positive: {
    strong: [
      // Exceptional service
      "excellent",
      "amazing",
      "fantastic",
      "wonderful",
      "outstanding",
      "perfect",
      "brilliant",
      "exceptional",
      "superb",
      "magnificent",
      "phenomenal",
      "incredible",
      "marvelous",
      "spectacular",
      "first-class",
      "top-notch",
      "world-class",
      "exemplary",
      "flawless",
      "impeccable",
      // Strong appreciation
      "love",
      "adore",
      "delighted",
      "thrilled",
      "ecstatic",
      "overjoyed",
      "blessed",
      "grateful",
      "appreciate greatly",
      "highly recommend",
      "extremely satisfied",
      "beyond expectations",
      // Resolution & success
      "resolved quickly",
      "fixed immediately",
      "sorted out perfectly",
      "handled brilliantly",
      "exceeded expectations",
      "went above and beyond",
      "outstanding support",
      "problem solved",
    ],
    moderate: [
      // Good service
      "good",
      "great",
      "nice",
      "helpful",
      "pleasant",
      "positive",
      "satisfactory",
      "competent",
      "reliable",
      "dependable",
      "trustworthy",
      "professional",
      "courteous",
      "polite",
      "respectful",
      // Efficiency
      "quick",
      "fast",
      "prompt",
      "efficient",
      "speedy",
      "timely",
      "swift",
      "rapid",
      "responsive",
      "immediate",
      "expedited",
      "streamlined",
      // Problem resolution
      "solved",
      "resolved",
      "fixed",
      "sorted",
      "handled",
      "addressed",
      "dealt with",
      "taken care of",
      "looked after",
      "managed well",
      "cleared up",
      "working on it",
      // Appreciation
      "thank",
      "thanks",
      "appreciate",
      "grateful",
      "pleased",
      "happy",
      "satisfied",
      "content",
      "glad",
      "relieved",
      "comfortable",
      // Customer feeling valued
      "feel cared",
      "feel valued",
      "feel heard",
      "feel appreciated",
      "feel respected",
      "truly cared",
      "really cared",
      "genuinely care",
      "you care",
      "you cared",
      // Knowledge & competence
      "knowledgeable",
      "informed",
      "experienced",
      "skilled",
      "capable",
      "qualified",
      "well-trained",
      "expert",
      "proficient",
      "understanding",
      "patient",
      // Communication
      "clear",
      "explained well",
      "easy to understand",
      "straightforward",
      "transparent",
      "kept informed",
      "good communication",
      "listened carefully",
      // Empathy & acknowledgment
      "i understand",
      "i can see",
      "i appreciate",
      "i recognize",
      "i hear you",
      "that must be",
      "i can imagine",
      "totally understand",
      "completely understand",
      "understand your frustration",
      "understand your concern",
      "i apologize",
      "apologize for",
      "sorry for",
      "sorry about",
      "my apologies",
      "let me help",
      "happy to help",
      "here to help",
      "assist you",
      // Solution-oriented language
      "let me",
      "i will",
      "i can",
      "what i can do",
      "what i will do",
      "let me check",
      "let me look",
      "let me see",
      "let me find",
      "solution",
      "resolve this",
      "fix this",
      "sort this out",
      // Refund & credit processing
      "processing refund",
      "processing credit",
      "issuing refund",
      "refund processed",
      "refund you",
      "credit your account",
      "crediting your account",
      "refunding you",
      // Ownership & accountability
      "taking ownership",
      "took ownership",
      "owned the mistake",
      "taking responsibility",
      "took responsibility",
      "accountable",
      "above and beyond",
      "went beyond",
      // Proactive handler actions
      "to ensure",
      "to prevent",
      "to avoid",
      "to make sure",
      "to guarantee",
      "i have escalated",
      "i have flagged",
      "i have noted",
      "i have documented",
    ],
    mild: [
      "okay",
      "fine",
      "decent",
      "acceptable",
      "reasonable",
      "adequate",
      "fair",
      "alright",
      "not bad",
      "passable",
      "tolerable",
      "satisfactory enough",
      "meets expectations",
      "standard",
      "average",
      "normal",
      "typical",
      "usual",
      "expected",
    ],
  },
  negative: {
    strong: [
      // Extreme dissatisfaction
      "terrible",
      "awful",
      "horrible",
      "worst",
      "appalling",
      "atrocious",
      "abysmal",
      "dreadful",
      "disgusting",
      "pathetic",
      "useless",
      "worthless",
      "incompetent",
      "unacceptable",
      // Strong emotions
      "furious",
      "outraged",
      "livid",
      "enraged",
      "infuriated",
      "incensed",
      "irate",
      "disgusted",
      "appalled",
      "shocked",
      "horrified",
      "devastated",
      // Severe issues
      "nightmare",
      "disaster",
      "catastrophe",
      "fiasco",
      "debacle",
      "shambles",
      "mess",
      "complete failure",
      "total disaster",
      "absolute nightmare",
      "utter chaos",
      // Strong negative actions
      "scam",
      "fraud",
      "rip-off",
      "cheated",
      "conned",
      "deceived",
      "misled",
      "lied to",
      "robbed",
      "stolen",
      "ripped off",
      "taken advantage of",
      // Complaints & escalation
      "complain formally",
      "file complaint",
      "report",
      "sue",
      "legal action",
      "ombudsman",
      "regulator",
      "solicitor",
      "lawyer",
      "compensation",
      "refund demanded",
    ],
    moderate: [
      // Frustration & stress
      "frustrated",
      "frustrating",
      "annoyed",
      "annoying",
      "irritated",
      "irritating",
      "upset",
      "upsetting",
      "angry",
      "cross",
      "displeased",
      "unhappy",
      "dissatisfied",
      "let down",
      "disappointed",
      "stressed",
      "stressful",
      "worried",
      "concerned",
      "anxious",
      "nervous",
      "tense",
      "overwhelmed",
      // Problems & issues
      "problem",
      "issue",
      "trouble",
      "difficulty",
      "complication",
      "concern",
      "worry",
      "complaint",
      "complain",
      "grievance",
      "dispute",
      "disagreement",
      // Service failures
      "failed",
      "failing",
      "failure",
      "didn't work",
      "doesn't work",
      "broken",
      "not working",
      "error",
      "mistake",
      "wrong",
      "incorrect",
      "inaccurate",
      "faulty",
      "defective",
      "out of service",
      "down",
      "offline",
      "unavailable",
      // Communication issues
      "confusing",
      "confused",
      "unclear",
      "complicated",
      "difficult to understand",
      "vague",
      "ambiguous",
      "misleading",
      "contradictory",
      "inconsistent",
      // Delays & waiting
      "delayed",
      "delay",
      "late",
      "overdue",
      "behind schedule",
      "taking too long",
      "still waiting",
      "not received",
      "missing",
      "lost",
      "waiting indefinitely",
      // Unprofessional behavior
      "rude",
      "unprofessional",
      "dismissive",
      "unhelpful",
      "disrespectful",
      "impolite",
      "condescending",
      "patronizing",
      "arrogant",
      "ignorant",
      // Helplessness
      "no help",
      "no solution",
      "no alternative",
      "no option",
      "stuck",
      "stranded",
      "desperate",
      "helpless",
      "hopeless",
      // Billing & payment issues
      "charged twice",
      "double charged",
      "overcharged",
      "incorrect charge",
      "wrong amount",
      "billing error",
      "payment error",
      "unauthorized charge",
      "unexpected charge",
      // Unexpected bills & high costs
      "facing a bill",
      "unexpected bill",
      "huge bill",
      "massive bill",
      "high bill",
      "expensive bill",
      "can't afford this",
      "too expensive",
      "outrageous cost",
      // Insurance claim issues
      "denial",
      "denied",
      "claim denied",
      "coverage denied",
      "rejected claim",
      "not covered",
      "no coverage",
      "won't cover",
      "refuse to cover",
      // System/technical failures
      "crashed",
      "crash",
      "system down",
      "unable to run",
      "unable to access",
      "nothing helped",
      "nothing worked",
      "still broken",
      "still failing",
      // Time wasted
      "wasted time",
      "wasted hours",
      "waste of time",
      "wasting my time",
    ],
  },
  urgency: [
    "urgent",
    "urgently",
    "asap",
    "immediately",
    "emergency",
    "critical",
    "pressing",
    "time-sensitive",
    "deadline",
    "right away",
    "straight away",
    "important",
    "tomorrow",
    "today",
    "now",
  ],
  escalation: [
    "manager",
    "supervisor",
    "senior",
    "escalate",
    "complaint",
    "formal complaint",
    "ombudsman",
    "regulator",
    "fca",
    "legal",
    "solicitor",
    "compensation",
  ],
  vulnerability: [
    // Financial vulnerability
    "elderly",
    "disabled",
    "vulnerable",
    "difficulty understanding",
    "health condition",
    "mental health",
    "bereavement",
    "financial difficulty",
    "hardship",
    "struggling",
    "budget",
    "budgeting",
    "afford",
    "can't afford",
    "cannot afford",
    "money problems",
    "financial stress",
    "financial strain",
    "tight budget",
    "limited income",
    "fixed income",
    "pension",
    "benefits",
    "unemployment",
    "unemployed",
    "redundancy",
    "redundant",
    "debt",
    "in debt",
    "owe",
    "owing",
    "overdue",
    "arrears",
    "behind on payments",
    "bankruptcy",
    "insolvency",
    "financial crisis",
    "money troubles",
    "messed up my budget",
    "budget constraints",
    "financial burden",
    // Personal/health vulnerability
    "cancer",
    "terminal illness",
    "chronic condition",
    "disability",
    "depression",
    "anxiety disorder",
    "ptsd",
    "dementia",
    "alzheimer",
    "stroke",
    "heart condition",
    "serious illness",
    "medical condition",
    "hospital",
    "hospitalized",
    "treatment",
    "medication",
    "care home",
    "carer",
    // Life events
    "death",
    "died",
    "passed away",
    "funeral",
    "divorce",
    "separated",
    "separation",
    "domestic abuse",
    "victim",
    "homeless",
    "eviction",
    "evicted",
    "repossession",
    "losing home",
    // Communication/understanding
    "hard to understand",
    "confused",
    "don't understand",
    "language barrier",
    "english not first language",
    "need help understanding",
    "learning difficulty",
    "literacy",
    "vision impaired",
    "hearing impaired",
    // Age-related
    "pensioner",
    "retired",
    "senior citizen",
    "old age",
    "aging",
  ],
  emotional_distress: [
    "stressed",
    "stress",
    "stressful",
    "anxious",
    "anxiety",
    "worried",
    "worry",
    "panic",
    "panicking",
    "overwhelmed",
    "breaking down",
    "crying",
    "tears",
    "desperate",
    "desperation",
    "hopeless",
    "helpless",
  ],
  dismissive: [
    "just have to wait",
    "nothing i can do",
    "nothing we can do",
    "can't help",
    "can't provide",
    "you'll just have to",
    "as i said",
    "like i said",
    "already told you",
    "not my department",
    "not my problem",
  ],
}

const vulnerabilityPatterns = [
  {
    pattern: /mental health|depression|anxiety|stress|breakdown|ptsd/i,
    type: "Mental Health",
    severity: "high" as const,
  },
  {
    pattern: /elderly|old age|pensioner|retired|oap|senior citizen|aging/i,
    type: "Age-related",
    severity: "medium" as const,
  },
  {
    pattern: /disabled|disability|wheelchair|blind|deaf|vision impaired|hearing impaired/i,
    type: "Disability",
    severity: "medium" as const,
  },
  {
    pattern: /bereaved|bereavement|passed away|died|death|funeral|lost.*loved/i,
    type: "Bereavement",
    severity: "high" as const,
  },
  {
    pattern:
      /financial difficult|money problems|can't afford|struggling to pay|hardship|debt|arrears|bankruptcy|insolvency/i,
    type: "Financial Hardship",
    severity: "high" as const,
  },
  {
    pattern: /don't understand|confused|confusing|complicated|difficult to understand|hard to understand/i,
    type: "Comprehension",
    severity: "medium" as const,
  },
  {
    pattern: /illness|ill|sick|hospital|cancer|treatment|surgery|chronic condition|terminal|medical condition/i,
    type: "Health Issues",
    severity: "medium" as const,
  },
  { pattern: /alone|lonely|no one to help|on my own|isolated/i, type: "Social Isolation", severity: "medium" as const },
  {
    pattern: /english.*second|not.*first language|interpreter|language barrier/i,
    type: "Language Barrier",
    severity: "medium" as const,
  },
  { pattern: /carer|caring for|look after|dependent/i, type: "Caring Responsibilities", severity: "low" as const },
  {
    pattern: /divorce|separated|relationship breakdown|domestic abuse/i,
    type: "Relationship Issues",
    severity: "medium" as const,
  },
  {
    pattern: /job loss|redundan|unemployed|lost.*job|unemployment/i,
    type: "Employment Issues",
    severity: "medium" as const,
  },
  { pattern: /homeless|eviction|evicted|repossession|losing home/i, type: "Housing Issues", severity: "high" as const },
  {
    pattern: /budget|tight budget|limited income|fixed income|pension|benefits/i,
    type: "Low Income",
    severity: "medium" as const,
  },
  {
    pattern: /crying|tears|breaking down|overwhelmed|desperate|helpless|hopeless/i,
    type: "Emotional Distress",
    severity: "high" as const,
  },
]

const complaintPatterns = [
  {
    pattern: /want to complain|making a complaint|formal complaint|lodge a complaint/i,
    type: "Direct Complaint",
    shouldLog: true,
  },
  { pattern: /speak to manager|supervisor|escalate|someone senior/i, type: "Escalation Request", shouldLog: true },
  { pattern: /ombudsman|fca|regulator|financial conduct|watchdog/i, type: "Regulatory Threat", shouldLog: true },
  { pattern: /solicitor|lawyer|legal action|sue|court|tribunal/i, type: "Legal Threat", shouldLog: true },
  {
    pattern: /mis-sold|missold|mis-selling|wasn't told|not informed|misrepresent/i,
    type: "Mis-selling Allegation",
    shouldLog: true,
  },
  { pattern: /compensation|refund|money back|reimburse/i, type: "Compensation Request", shouldLog: true },
  { pattern: /unfair|discriminat|treated differently|bias/i, type: "Unfair Treatment", shouldLog: true },
  {
    pattern: /cancel.*policy|leaving|switching|going elsewhere|cancel my account/i,
    type: "Cancellation Intent",
    shouldLog: false,
  },
  {
    pattern: /never again|last time|worst experience|appalling service/i,
    type: "Service Dissatisfaction",
    shouldLog: false,
  },
  { pattern: /lied to|deceived|misled|false information|fraud|scam/i, type: "Deception Allegation", shouldLog: true },
  { pattern: /trading standards|ofcom|ico|data protection/i, type: "Regulatory Body", shouldLog: true },
  { pattern: /social media|twitter|facebook|review|trustpilot/i, type: "Public Complaint Threat", shouldLog: false },
]

const themes: Record<string, string[]> = {
  "Pricing & Payments": [
    "price",
    "cost",
    "expensive",
    "cheap",
    "affordable",
    "premium",
    "fee",
    "charge",
    "payment",
    "direct debit",
    "instalment",
    "monthly",
    "annual",
    "increase",
    "renewal price",
    "quote",
  ],
  "Customer Service": [
    "service",
    "support",
    "help",
    "assist",
    "agent",
    "representative",
    "staff",
    "advisor",
    "call centre",
    "hold",
    "waiting",
    "callback",
    "response time",
  ],
  Claims: [
    "claim",
    "claims",
    "accident",
    "damage",
    "repair",
    "garage",
    "assessor",
    "total loss",
    "write off",
    "settlement",
    "payout",
    "excess",
    "deductible",
  ],
  "Policy Changes": [
    "change",
    "amendment",
    "update",
    "modify",
    "mta",
    "mid-term",
    "renewal",
    "cancel",
    "add driver",
    "remove driver",
    "change address",
    "change vehicle",
  ],
  Documentation: [
    "document",
    "certificate",
    "schedule",
    "policy wording",
    "email",
    "letter",
    "paperwork",
    "proof",
    "confirmation",
    "statement",
  ],
  "Wait Times": [
    "waiting",
    "wait",
    "hold",
    "queue",
    "callback",
    "delayed",
    "slow",
    "long time",
    "ages",
    "hours",
    "still waiting",
  ],
  Communication: [
    "call",
    "phone",
    "email",
    "contact",
    "respond",
    "reply",
    "communication",
    "told",
    "informed",
    "update",
    "notification",
  ],
  "Cover & Benefits": [
    "cover",
    "covered",
    "insured",
    "benefit",
    "protected",
    "excess",
    "breakdown",
    "comprehensive",
    "third party",
    "liability",
    "protection",
  ],
  "Technical Issues": [
    "website",
    "online",
    "app",
    "login",
    "password",
    "error",
    "system",
    "technical",
    "portal",
    "account",
    "access",
  ],
  "Billing Issues": [
    "bill",
    "invoice",
    "charged",
    "overcharged",
    "double charged",
    "incorrect amount",
    "payment failed",
    "direct debit",
    "refund",
  ],
}

const surveyWeightMultiplier = 1.2
const transcriptWeightMultiplier = 0.8

// Helper function for whole-word matching
const matchesWholeWord = (text: string, keyword: string): boolean => {
  const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  const regex = new RegExp(`\\b${escapedKeyword}\\b`, "i")
  return regex.test(text)
}

export function analyzeSentiment(
  text: string,
  analysisType: "survey" | "transcript" = "transcript",
): SentimentAnalysis {
  const weightMultiplier = analysisType === "survey" ? surveyWeightMultiplier : transcriptWeightMultiplier

  // Split into sentences/phrases
  const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0)
  const phrases: PhraseAnalysis[] = []

  let totalScore = 0

  sentences.forEach((sentence) => {
    const lowerSentence = sentence.toLowerCase()
    const keywords: string[] = []
    let phraseScore = 0
    let positiveWeight = 0
    let negativeWeight = 0

    // Check positive keywords with strength levels
    for (const [strength, keywordList] of Object.entries(SENTIMENT_KEYWORDS.positive)) {
      for (const keyword of keywordList) {
        if (matchesWholeWord(lowerSentence, keyword)) {
          keywords.push(keyword)
          const weight = strength === "strong" ? 3 : strength === "moderate" ? 2 : 1
          positiveWeight += weight * weightMultiplier
        }
      }
    }

    // Check negative keywords with strength levels
    for (const [strength, keywordList] of Object.entries(SENTIMENT_KEYWORDS.negative)) {
      for (const keyword of keywordList) {
        if (matchesWholeWord(lowerSentence, keyword)) {
          keywords.push(keyword)
          const weight = strength === "strong" ? 3 : 2
          negativeWeight += weight * weightMultiplier
        }
      }
    }

    // Check emotional distress
    for (const keyword of SENTIMENT_KEYWORDS.emotional_distress) {
      if (matchesWholeWord(lowerSentence, keyword)) {
        keywords.push(`[emotional] ${keyword}`)
        negativeWeight += 2.5 * weightMultiplier
      }
    }

    // Check dismissive language
    for (const keyword of SENTIMENT_KEYWORDS.dismissive) {
      if (matchesWholeWord(lowerSentence, keyword)) {
        keywords.push(`[dismissive] ${keyword}`)
        negativeWeight += 2 * weightMultiplier
      }
    }

    // Check urgency
    for (const keyword of SENTIMENT_KEYWORDS.urgency) {
      if (matchesWholeWord(lowerSentence, keyword)) {
        keywords.push(`[urgent] ${keyword}`)
      }
    }

    // Check vulnerability
    for (const keyword of SENTIMENT_KEYWORDS.vulnerability) {
      if (matchesWholeWord(lowerSentence, keyword)) {
        keywords.push(`[vulnerable] ${keyword}`)
        negativeWeight += 2 * weightMultiplier // Vulnerability indicates customer distress
      }
    }

    phraseScore = positiveWeight - negativeWeight
    totalScore += phraseScore

    let sentiment: "positive" | "negative" | "neutral"
    if (phraseScore > 1) {
      sentiment = "positive"
    } else if (phraseScore < -1) {
      sentiment = "negative"
    } else {
      sentiment = "neutral"
    }

    phrases.push({
      text: sentence.trim(),
      sentiment,
      keywords: [...new Set(keywords)],
      score: phraseScore,
    })
  })

  // Calculate percentage scores
  const totalPhrases = phrases.length || 1
  const positiveCount = phrases.filter((p) => p.sentiment === "positive").length
  const negativeCount = phrases.filter((p) => p.sentiment === "negative").length
  const neutralCount = phrases.filter((p) => p.sentiment === "neutral").length

  const scores = {
    positive: Math.round((positiveCount / totalPhrases) * 100),
    neutral: Math.round((neutralCount / totalPhrases) * 100),
    negative: Math.round((negativeCount / totalPhrases) * 100),
  }

  // Determine overall sentiment
  let overallSentiment: "positive" | "negative" | "neutral"
  if (totalScore > 3) {
    overallSentiment = "positive"
  } else if (totalScore < -3) {
    overallSentiment = "negative"
  } else {
    overallSentiment = "neutral"
  }

  // Detect themes
  const detectedThemes: string[] = []
  const lowerText = text.toLowerCase()
  Object.entries(themes).forEach(([theme, keywordList]) => {
    if (keywordList.some((keyword) => lowerText.includes(keyword))) {
      detectedThemes.push(theme)
    }
  })

  // Detect vulnerabilities
  const vulnerabilities: VulnerabilityIndicator[] = []
  vulnerabilityPatterns.forEach(({ pattern, type, severity }) => {
    const match = text.match(pattern)
    if (match) {
      vulnerabilities.push({
        type,
        phrase: match[0],
        severity,
      })
    }
  })

  // Detect complaints
  const complaints: ComplaintIndicator[] = []
  complaintPatterns.forEach(({ pattern, type, shouldLog }) => {
    const match = text.match(pattern)
    if (match) {
      complaints.push({
        type,
        phrase: match[0],
        shouldLog,
      })
    }
  })

  // Generate coaching feedback
  const coaching: string[] = []

  if (scores.negative > 50) {
    coaching.push(
      "CRITICAL: High negative sentiment detected. Focus on acknowledging concerns and demonstrating empathy before problem-solving.",
    )
  } else if (scores.negative > 30) {
    coaching.push(
      "Moderate negative sentiment present. Use empathy statements like 'I understand how frustrating this must be' to build rapport.",
    )
  }

  if (lowerText.includes("wait") || lowerText.includes("delay") || lowerText.includes("hold")) {
    coaching.push(
      "Customer mentioned waiting or delays. Apologize sincerely and provide clear timelines for resolution.",
    )
  }

  if (lowerText.match(/frustrat|angry|furious|livid|outraged/i)) {
    coaching.push(
      "Customer expressed strong frustration. Allow them to vent, acknowledge feelings, then move to solutions.",
    )
  }

  // Check for emotional distress
  if (phrases.some((p) => p.keywords.some((k) => k.includes("[emotional]")))) {
    coaching.push(
      "ALERT: Customer showing emotional distress. Provide empathy and immediate support. Consider offering a callback or specialist support.",
    )
  }

  // Check for dismissive language
  if (phrases.some((p) => p.keywords.some((k) => k.includes("[dismissive]")))) {
    coaching.push(
      "WARNING: Dismissive language detected in conversation. Agent needs coaching on empathy and problem-solving.",
    )
  }

  if (vulnerabilities.length > 0) {
    const vulnTypes = [...new Set(vulnerabilities.map((v) => v.type))].join(", ")
    coaching.push(
      `VULNERABILITY ALERT: ${vulnerabilities.length} indicator(s) detected (${vulnTypes}). Adjust communication approach, document in customer record, and consider specialist support.`,
    )
  }

  if (complaints.filter((c) => c.shouldLog).length > 0) {
    coaching.push(
      "COMPLAINT INDICATOR: Expressions suggest this may need to be logged as a formal complaint. Follow complaints procedure immediately.",
    )
  }

  if (scores.positive > 60) {
    coaching.push(
      "Excellent! Customer expressed highly positive sentiment. Maintain this service level and look for upsell opportunities.",
    )
  }

  if (detectedThemes.includes("Claims") && scores.negative > 20) {
    coaching.push(
      "Claims-related negativity detected. Ensure clear explanation of process and manage expectations on timelines.",
    )
  }

  if (detectedThemes.includes("Pricing & Payments") && scores.negative > 20) {
    coaching.push("Pricing concerns detected. Explain value proposition and available payment options clearly.")
  }

  if (detectedThemes.includes("Wait Times")) {
    coaching.push("Wait time concerns raised. Acknowledge the inconvenience and explain steps being taken to resolve.")
  }

  return {
    overallSentiment,
    scores,
    phrases,
    themes: detectedThemes,
    coaching,
    vulnerabilities,
    complaints,
    analysisType,
  }
}

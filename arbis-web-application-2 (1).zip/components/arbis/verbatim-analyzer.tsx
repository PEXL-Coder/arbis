"use client"

import { useState } from "react"
import styles from "./verbatim-analyzer.module.css"
import { analyzeSentiment, type SentimentAnalysis } from "./verbatim-analyzer-engine"

export default function VerbatimAnalyzer() {
  const [inputText, setInputText] = useState("")
  const [analysis, setAnalysis] = useState<SentimentAnalysis | null>(null)
  const [analysisType, setAnalysisType] = useState<"survey" | "transcript">("transcript")

  const handleAnalyze = () => {
    if (inputText.trim()) {
      const result = analyzeSentiment(inputText, analysisType)
      setAnalysis(result)
      localStorage.setItem(
        "arbis_last_analysis",
        JSON.stringify({
          scores: result.scores,
          vulnerabilities: result.vulnerabilities.map((v) => v.type),
          complaints: result.complaints.filter((c) => c.shouldLog).map((c) => c.type),
          timestamp: new Date().toISOString(),
        }),
      )
    }
  }

  const handleClear = () => {
    setInputText("")
    setAnalysis(null)
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "#10B981"
      case "negative":
        return "#EF4444"
      case "neutral":
        return "#6B7280"
      default:
        return "#6B7280"
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "#EF4444"
      case "medium":
        return "#F59E0B"
      case "low":
        return "#3B82F6"
      default:
        return "#6B7280"
    }
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Verbatim Analyzer</h1>
        <p className={styles.subtitle}>
          Analyze customer sentiment from survey responses or call transcripts with phrase-level breakdown,
          vulnerability detection, complaint identification, and coaching feedback.
        </p>
      </div>

      <div className={styles.toggleSection}>
        <label className={styles.toggleLabel}>Analysis Type:</label>
        <div className={styles.toggleButtons}>
          <button
            className={`${styles.toggleButton} ${analysisType === "survey" ? styles.toggleActive : ""}`}
            onClick={() => setAnalysisType("survey")}
          >
            Survey Verbatim
          </button>
          <button
            className={`${styles.toggleButton} ${analysisType === "transcript" ? styles.toggleActive : ""}`}
            onClick={() => setAnalysisType("transcript")}
          >
            Call Transcript
          </button>
        </div>
      </div>

      <div className={styles.inputSection}>
        <label htmlFor="verbatim-input" className={styles.label}>
          Enter {analysisType === "survey" ? "Survey Response" : "Call Transcript"}
        </label>
        <textarea
          id="verbatim-input"
          className={styles.textarea}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={
            analysisType === "survey" ? "Paste customer survey response here..." : "Paste call transcript here..."
          }
          rows={10}
        />
        <div className={styles.buttonGroup}>
          <button className={styles.primaryButton} onClick={handleAnalyze}>
            Analyze Text
          </button>
          <button className={styles.secondaryButton} onClick={handleClear}>
            Clear
          </button>
        </div>
      </div>

      {analysis && (
        <div className={styles.resultsSection}>
          {/* Overall Sentiment */}
          <div className={styles.overallSentiment}>
            <h2 className={styles.resultTitle}>Overall Sentiment</h2>
            <div
              className={styles.sentimentBadge}
              style={{ backgroundColor: getSentimentColor(analysis.overallSentiment) }}
            >
              {analysis.overallSentiment.toUpperCase()}
            </div>
            <div className={styles.scores}>
              <div className={styles.scoreItem}>
                <span className={styles.scoreLabel}>Positive</span>
                <span className={styles.scoreValue} style={{ color: "#10B981" }}>
                  {analysis.scores.positive}%
                </span>
              </div>
              <div className={styles.scoreItem}>
                <span className={styles.scoreLabel}>Neutral</span>
                <span className={styles.scoreValue} style={{ color: "#6B7280" }}>
                  {analysis.scores.neutral}%
                </span>
              </div>
              <div className={styles.scoreItem}>
                <span className={styles.scoreLabel}>Negative</span>
                <span className={styles.scoreValue} style={{ color: "#EF4444" }}>
                  {analysis.scores.negative}%
                </span>
              </div>
            </div>
          </div>

          {analysis.themes.length > 0 && (
            <div className={styles.themesSection}>
              <h2 className={styles.resultTitle}>Key Themes</h2>
              <div className={styles.themeGrid}>
                {analysis.themes.map((theme, index) => (
                  <div key={index} className={styles.themeCard}>
                    {theme}
                  </div>
                ))}
              </div>
            </div>
          )}

          {analysis.coaching.length > 0 && (
            <div className={styles.coachingSection}>
              <h2 className={styles.resultTitle}>Coaching Feedback</h2>
              <ul className={styles.coachingList}>
                {analysis.coaching.map((tip, index) => (
                  <li
                    key={index}
                    className={`${styles.coachingItem} ${tip.includes("ALERT") || tip.includes("COMPLAINT") ? styles.coachingAlert : ""}`}
                  >
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {analysis.vulnerabilities.length > 0 && (
            <div className={styles.vulnerabilitySection}>
              <h2 className={styles.resultTitle}>Vulnerability Indicators Detected</h2>
              <div className={styles.alertList}>
                {analysis.vulnerabilities.map((vuln, index) => (
                  <div
                    key={index}
                    className={styles.alertCard}
                    style={{ borderLeftColor: getSeverityColor(vuln.severity) }}
                  >
                    <div className={styles.alertHeader}>
                      <span className={styles.alertType}>{vuln.type}</span>
                      <span
                        className={styles.alertSeverity}
                        style={{ backgroundColor: getSeverityColor(vuln.severity) }}
                      >
                        {vuln.severity.toUpperCase()}
                      </span>
                    </div>
                    <p className={styles.alertPhrase}>"{vuln.phrase}"</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {analysis.complaints.length > 0 && (
            <div className={styles.complaintSection}>
              <h2 className={styles.resultTitle}>Potential Complaints Identified</h2>
              <div className={styles.alertList}>
                {analysis.complaints.map((complaint, index) => (
                  <div key={index} className={styles.complaintCard}>
                    <div className={styles.alertHeader}>
                      <span className={styles.alertType}>{complaint.type}</span>
                      {complaint.shouldLog && <span className={styles.logBadge}>SHOULD LOG</span>}
                    </div>
                    <p className={styles.alertPhrase}>"{complaint.phrase}"</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Phrase-Level Analysis - now below themes and coaching */}
          <div className={styles.phrasesSection}>
            <h2 className={styles.resultTitle}>Phrase-Level Analysis</h2>
            <div className={styles.phraseList}>
              {analysis.phrases.map((phrase, index) => (
                <div
                  key={index}
                  className={styles.phraseCard}
                  style={{ borderLeftColor: getSentimentColor(phrase.sentiment) }}
                >
                  <div className={styles.phraseText}>{phrase.text}</div>
                  <div className={styles.phraseFooter}>
                    <span className={styles.phraseSentiment} style={{ color: getSentimentColor(phrase.sentiment) }}>
                      {phrase.sentiment.toUpperCase()}
                    </span>
                    <span className={styles.phraseScore}>
                      Score: {phrase.score > 0 ? "+" : ""}
                      {phrase.score.toFixed(1)}
                    </span>
                  </div>
                  {phrase.keywords.length > 0 && (
                    <div className={styles.keywords}>
                      {phrase.keywords.map((keyword, kidx) => (
                        <span key={kidx} className={styles.keyword}>
                          {keyword}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

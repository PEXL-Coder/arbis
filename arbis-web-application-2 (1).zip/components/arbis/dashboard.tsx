"use client"

import { useState, useEffect } from "react"
import styles from "./dashboard.module.css"

interface DashboardProps {
  onNavigate: (view: string, data?: any) => void
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [verbatimStats, setVerbatimStats] = useState<any>(null)

  useEffect(() => {
    // Load verbatim stats from localStorage if available
    const savedAnalysis = localStorage.getItem("arbis_last_analysis")
    if (savedAnalysis) {
      setVerbatimStats(JSON.parse(savedAnalysis))
    }
  }, [])

  const performanceMetrics = [
    { label: "Calls", value: "12" },
    { label: "AHT", value: "4m 30s" },
    { label: "Hold", value: "16s" },
    { label: "Wrap", value: "13s" },
    { label: "Conex", value: "83.6" },
    { label: "DFT", value: "0.8" },
  ]

  const frequentArticles = [
    { title: "Understanding Cover Types", id: 10 },
    { title: "Policy Cancellation", id: 7 },
    { title: "Verifying Customer Identity", id: 6 },
  ]

  const frequentFlows = [
    { title: "New Policy Inquiry", stepId: 0 },
    { title: "Change of Address", stepId: 31 },
    { title: "Admin Tasks", stepId: 34 },
  ]

  const handleArticleClick = (articleId: number) => {
    onNavigate("knowledge-hub", { articleId })
  }

  const handleFlowClick = (stepId: number) => {
    onNavigate("guided-flow", { stepId })
  }

  return (
    <div className={styles.container}>
      <div className={styles.grid}>
        <section className={styles.card}>
          <h2 className={styles.cardTitle}>My Performance</h2>
          <div className={styles.metrics}>
            {performanceMetrics.map((metric) => (
              <div key={metric.label} className={styles.metric}>
                <div className={styles.metricValue}>{metric.value}</div>
                <div className={styles.metricLabel}>{metric.label}</div>
              </div>
            ))}
          </div>
        </section>

        <section className={styles.card}>
          <h2 className={styles.cardTitle}>Frequent Articles</h2>
          <ul className={styles.list}>
            {frequentArticles.map((article) => (
              <li
                key={article.id}
                className={`${styles.listItem} ${styles.clickable}`}
                onClick={() => handleArticleClick(article.id)}
              >
                📄 {article.title}
              </li>
            ))}
          </ul>
        </section>

        <section className={styles.card}>
          <h2 className={styles.cardTitle}>Frequent Flows</h2>
          <ul className={styles.list}>
            {frequentFlows.map((flow, index) => (
              <li
                key={index}
                className={`${styles.listItem} ${styles.clickable}`}
                onClick={() => handleFlowClick(flow.stepId)}
              >
                🔄 {flow.title}
              </li>
            ))}
          </ul>
        </section>

        <section className={`${styles.card} ${styles.fullWidth}`}>
          <h2 className={styles.cardTitle}>Verbatim Analysis Insights</h2>
          {verbatimStats ? (
            <div className={styles.verbatimInsights}>
              <div className={styles.statsGrid}>
                <div className={styles.statCard}>
                  <div className={styles.statValue} style={{ color: "#10B981" }}>
                    {verbatimStats.scores?.positive || 0}%
                  </div>
                  <div className={styles.statLabel}>Positive</div>
                </div>
                <div className={styles.statCard}>
                  <div className={styles.statValue} style={{ color: "#F59E0B" }}>
                    {verbatimStats.scores?.neutral || 0}%
                  </div>
                  <div className={styles.statLabel}>Neutral</div>
                </div>
                <div className={styles.statCard}>
                  <div className={styles.statValue} style={{ color: "#EF4444" }}>
                    {verbatimStats.scores?.negative || 0}%
                  </div>
                  <div className={styles.statLabel}>Negative</div>
                </div>
              </div>
              {verbatimStats.vulnerabilities && verbatimStats.vulnerabilities.length > 0 && (
                <div className={styles.alertBox}>
                  <strong>⚠️ Vulnerabilities Detected:</strong>
                  <div className={styles.alertTags}>
                    {verbatimStats.vulnerabilities.slice(0, 3).map((v: string, i: number) => (
                      <span key={i} className={styles.alertTag}>
                        {v}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              <button className={styles.viewButton} onClick={() => onNavigate("verbatim-analyzer")}>
                View Full Analysis →
              </button>
            </div>
          ) : (
            <p className={styles.emptyState}>
              No analysis data yet.{" "}
              <span className={styles.link} onClick={() => onNavigate("verbatim-analyzer")}>
                Visit Verbatim Analyzer
              </span>{" "}
              to start analyzing.
            </p>
          )}
        </section>
      </div>
    </div>
  )
}

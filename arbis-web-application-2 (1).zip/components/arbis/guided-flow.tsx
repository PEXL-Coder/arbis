"use client"

import { useState, useEffect } from "react"
import styles from "./guided-flow.module.css"
import { guidedFlowSteps, knowledgeArticles } from "./guided-flow-data"

interface GuidedFlowProps {
  initialStepId?: number
}

export default function GuidedFlow({ initialStepId }: GuidedFlowProps) {
  const [currentStep, setCurrentStep] = useState(initialStepId || 0)
  const [callNotes, setCallNotes] = useState("")
  const [history, setHistory] = useState<Array<{ step: number; option: string }>>([])
  const [showArticle, setShowArticle] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState<"flow" | "knowledge" | "navigation">("flow")

  useEffect(() => {
    if (initialStepId !== undefined) {
      setCurrentStep(initialStepId)
    }
  }, [initialStepId])

  const currentFlowStep = guidedFlowSteps[currentStep]

  const handleOptionSelect = (option: string) => {
    const nextStepId = currentFlowStep.next[option]

    // Generate notes - only record the option selected
    const timestamp = new Date().toLocaleTimeString()
    const noteEntry = `[${timestamp}] ${currentFlowStep.title} → ${option}\n`
    setCallNotes((prev) => prev + noteEntry)

    // Add to history for back navigation
    setHistory((prev) => [...prev, { step: currentStep, option }])

    // Auto-navigate to next step or end call
    if (nextStepId === -1) {
      setCallNotes((prev) => prev + `[${timestamp}] ===== CALL ENDED =====\n\n`)
    } else {
      setCurrentStep(nextStepId)
      setActiveTab("flow")
    }
  }

  const handlePrevious = () => {
    if (history.length > 0) {
      const lastHistory = history[history.length - 1]
      setCurrentStep(lastHistory.step)
      setHistory((prev) => prev.slice(0, -1))
    }
  }

  const handleStartNew = () => {
    setCurrentStep(0)
    setCallNotes("")
    setHistory([])
    setActiveTab("flow")
  }

  const copyNotes = () => {
    navigator.clipboard.writeText(callNotes)
  }

  const getRelatedArticles = () => {
    const articleIds = currentFlowStep.articleIds || currentFlowStep.knowledgeLinks || []
    return articleIds.map((id) => knowledgeArticles.find((a) => a.id === id)).filter(Boolean)
  }

  return (
    <div className={styles.container}>
      <div className={styles.mainPanel}>
        <div className={styles.header}>
          <h1 className={styles.title}>Guided Call Flow</h1>
        </div>

        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${activeTab === "flow" ? styles.activeTab : ""}`}
            onClick={() => setActiveTab("flow")}
          >
            Flow
          </button>
          <button
            className={`${styles.tab} ${activeTab === "knowledge" ? styles.activeTab : ""}`}
            onClick={() => setActiveTab("knowledge")}
          >
            Knowledge Articles
          </button>
          <button
            className={`${styles.tab} ${activeTab === "navigation" ? styles.activeTab : ""}`}
            onClick={() => setActiveTab("navigation")}
          >
            Navigation
          </button>
        </div>

        <div className={styles.content}>
          {/* TAB 1: FLOW - Options in same block as question, no related articles */}
          {activeTab === "flow" && (
            <div className={styles.phrasesPanel}>
              <div className={styles.stepInfo}>
                <span className={styles.stepNumber}>
                  Step {currentStep + 1} of {guidedFlowSteps.length}
                </span>
                <h2 className={styles.stepTitle}>{currentFlowStep.title}</h2>
              </div>

              <div className={styles.questionBlock}>
                <h3 className={styles.sectionTitle}>Question</h3>
                <p className={styles.scriptText}>{currentFlowStep.question}</p>
                <div className={styles.optionsSection}>
                  <h4 className={styles.optionsLabel}>Select Option (Auto-advances):</h4>
                  <div className={styles.optionGrid}>
                    {currentFlowStep.options.map((option, idx) => (
                      <button key={idx} className={styles.optionButton} onClick={() => handleOptionSelect(option)}>
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {currentFlowStep.phrases && currentFlowStep.phrases.length > 0 && (
                <div className={styles.phrasesBox}>
                  <h4 className={styles.sectionTitle}>Key Phrases</h4>
                  <ul className={styles.phraseList}>
                    {currentFlowStep.phrases.map((phrase, idx) => (
                      <li key={idx} className={styles.phraseItem}>
                        "{phrase}"
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {currentFlowStep.empathyPhrases && currentFlowStep.empathyPhrases.length > 0 && (
                <div className={styles.empathyBox}>
                  <h4 className={styles.sectionTitle}>Empathy Phrases</h4>
                  <ul className={styles.phraseList}>
                    {currentFlowStep.empathyPhrases.map((phrase, idx) => (
                      <li key={idx} className={styles.phraseItem}>
                        "{phrase}"
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {currentFlowStep.rebuttals && currentFlowStep.rebuttals.length > 0 && (
                <div className={styles.rebuttalsBox}>
                  <h4 className={styles.sectionTitle}>Rebuttal Phrases</h4>
                  <ul className={styles.rebuttalList}>
                    {currentFlowStep.rebuttals.map((rebuttal, idx) => (
                      <li key={idx} className={styles.rebuttalItem}>
                        "{rebuttal}"
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: KNOWLEDGE ARTICLES - Related articles moved here */}
          {activeTab === "knowledge" && (
            <div className={styles.knowledgePanel}>
              <h3 className={styles.sectionTitle}>Related Knowledge Articles for Current Step</h3>
              {getRelatedArticles().length > 0 ? (
                <div className={styles.articlesGrid}>
                  {getRelatedArticles().map((article) => (
                    <div key={article!.id} className={styles.articleCard} onClick={() => setShowArticle(article!.id)}>
                      <div className={styles.articleCategory}>{article!.category}</div>
                      <div className={styles.articleTitle}>{article!.title}</div>
                      <div className={styles.articlePreview}>{article!.content.substring(0, 150)}...</div>
                      <span className={styles.readMore}>Click to read full article</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className={styles.emptyState}>
                  No specific articles linked to this step. Browse all articles in Knowledge Hub from the sidebar.
                </p>
              )}

              <div className={styles.allArticlesSection}>
                <h3 className={styles.sectionTitle}>All Available Articles</h3>
                <div className={styles.articlesGrid}>
                  {knowledgeArticles.slice(0, 12).map((article) => (
                    <div key={article.id} className={styles.articleCard} onClick={() => setShowArticle(article.id)}>
                      <div className={styles.articleCategory}>{article.category}</div>
                      <div className={styles.articleTitle}>{article.title}</div>
                      <span className={styles.readMore}>Click to read</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: NAVIGATION/SCREENSHOTS */}
          {activeTab === "navigation" && (
            <div className={styles.navigationPanel}>
              <h3 className={styles.sectionTitle}>System Navigation</h3>
              {currentFlowStep.screenshot ? (
                <div className={styles.navigationCard}>
                  <div className={styles.navLabel}>Navigate to:</div>
                  <div className={styles.navScreen}>{currentFlowStep.screenshot}</div>
                  <p className={styles.navInstructions}>
                    Follow the standard navigation path from the main menu to reach this screen and complete the current
                    step.
                  </p>
                </div>
              ) : (
                <p className={styles.emptyState}>No specific navigation guidance for this step.</p>
              )}

              <div className={styles.navTips}>
                <h4 className={styles.sectionTitle}>Quick Navigation Tips</h4>
                <ul className={styles.tipsList}>
                  <li>Use keyboard shortcuts where available for faster navigation</li>
                  <li>Keep customer record open in a separate tab for reference</li>
                  <li>Document any system issues in the notes panel</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        <div className={styles.controls}>
          <button className={styles.controlButton} onClick={handlePrevious} disabled={history.length === 0}>
            PREVIOUS
          </button>
          <button className={styles.controlButton} onClick={handleStartNew}>
            START NEW CALL
          </button>
        </div>
      </div>

      <div className={styles.notesPanel}>
        <h3 className={styles.notesTitle}>Call Notes (Auto-Generated & Editable)</h3>
        <textarea
          className={styles.notesTextarea}
          value={callNotes}
          onChange={(e) => setCallNotes(e.target.value)}
          placeholder="Notes will be automatically generated as you select options. You can edit them as needed..."
        />
        <div className={styles.notesButtons}>
          <button className={styles.notesButton} onClick={copyNotes}>
            Copy Notes
          </button>
          <button className={styles.notesButton} onClick={() => setCallNotes("")}>
            Clear Notes
          </button>
        </div>
      </div>

      {showArticle !== null && (
        <div className={styles.modal} onClick={() => setShowArticle(null)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            {(() => {
              const article = knowledgeArticles.find((a) => a.id === showArticle)
              if (!article) return null
              return (
                <>
                  <div className={styles.modalHeader}>
                    <span className={styles.modalCategory}>{article.category}</span>
                    <h3 className={styles.modalTitle}>{article.title}</h3>
                  </div>
                  <div className={styles.modalBody}>
                    <div className={styles.articleFullContent}>
                      <p>{article.content}</p>
                    </div>
                    {article.steps && article.steps.length > 0 && (
                      <div className={styles.articleSteps}>
                        <h4>Procedure / Steps:</h4>
                        <ol>
                          {article.steps.map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>
                    )}
                  </div>
                  <button className={styles.modalClose} onClick={() => setShowArticle(null)}>
                    Close Article
                  </button>
                </>
              )
            })()}
          </div>
        </div>
      )}
    </div>
  )
}

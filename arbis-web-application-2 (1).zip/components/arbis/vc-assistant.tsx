"use client"

import { useState } from "react"
import styles from "./vc-assistant.module.css"

interface VCNode {
  id: string
  question: string
  options: Array<{ label: string; next: string | null; flag?: boolean }>
}

const vcTree: Record<string, VCNode> = {
  start: {
    id: "start",
    question: "Is the customer having difficulty understanding or communicating?",
    options: [
      { label: "Yes", next: "communication", flag: true },
      { label: "No", next: "health" },
    ],
  },
  communication: {
    id: "communication",
    question: "What type of communication difficulty?",
    options: [
      { label: "Language barrier", next: "language", flag: true },
      { label: "Hearing impairment", next: "hearing", flag: true },
      { label: "Speech difficulty", next: "speech", flag: true },
      { label: "Cognitive difficulty", next: "cognitive", flag: true },
    ],
  },
  health: {
    id: "health",
    question: "Does the customer have any health conditions affecting this interaction?",
    options: [
      { label: "Yes", next: "health_details", flag: true },
      { label: "No", next: "financial" },
    ],
  },
  health_details: {
    id: "health_details",
    question: "Please specify the health-related vulnerability:",
    options: [
      { label: "Mental health condition", next: null, flag: true },
      { label: "Physical disability", next: null, flag: true },
      { label: "Serious illness", next: null, flag: true },
      { label: "Recent bereavement", next: null, flag: true },
    ],
  },
  financial: {
    id: "financial",
    question: "Is the customer experiencing financial difficulties?",
    options: [
      { label: "Yes", next: "financial_details", flag: true },
      { label: "No", next: "life_events" },
    ],
  },
  financial_details: {
    id: "financial_details",
    question: "What type of financial difficulty?",
    options: [
      { label: "Unemployment", next: null, flag: true },
      { label: "Debt issues", next: null, flag: true },
      { label: "Income reduction", next: null, flag: true },
      { label: "Unexpected expenses", next: null, flag: true },
    ],
  },
  life_events: {
    id: "life_events",
    question: "Has the customer experienced any significant life events?",
    options: [
      { label: "Recent bereavement", next: null, flag: true },
      { label: "Relationship breakdown", next: null, flag: true },
      { label: "Victim of crime/abuse", next: null, flag: true },
      { label: "None applicable", next: null, flag: false },
    ],
  },
  language: {
    id: "language",
    question: "Action required for language barrier:",
    options: [
      { label: "Offer interpreter services", next: null, flag: true },
      { label: "Provide written materials in preferred language", next: null, flag: true },
    ],
  },
  hearing: {
    id: "hearing",
    question: "Action required for hearing impairment:",
    options: [
      { label: "Offer text relay service", next: null, flag: true },
      { label: "Provide written communication options", next: null, flag: true },
    ],
  },
  speech: {
    id: "speech",
    question: "Action required for speech difficulty:",
    options: [
      { label: "Allow extra time for communication", next: null, flag: true },
      { label: "Offer alternative communication methods", next: null, flag: true },
    ],
  },
  cognitive: {
    id: "cognitive",
    question: "Action required for cognitive difficulty:",
    options: [
      { label: "Simplify language and explanations", next: null, flag: true },
      { label: "Offer to involve carer/representative", next: null, flag: true },
      { label: "Provide information in multiple formats", next: null, flag: true },
    ],
  },
}

export default function VCAssistant() {
  const [currentNode, setCurrentNode] = useState<string>("start")
  const [path, setPath] = useState<string[]>(["start"])
  const [vulnerabilityFlags, setVulnerabilityFlags] = useState<string[]>([])
  const [completed, setCompleted] = useState(false)

  const node = vcTree[currentNode]

  const handleOption = (next: string | null, label: string, flag?: boolean) => {
    if (flag) {
      setVulnerabilityFlags([...vulnerabilityFlags, label])
    }

    if (next) {
      setCurrentNode(next)
      setPath([...path, next])
    } else {
      setCompleted(true)
    }
  }

  const handleReset = () => {
    setCurrentNode("start")
    setPath(["start"])
    setVulnerabilityFlags([])
    setCompleted(false)
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>VC Assistant (Vulnerable Customer)</h1>
        <p className={styles.subtitle}>
          Document and identify vulnerable customer indicators to provide appropriate support
        </p>
      </div>

      {!completed ? (
        <div className={styles.assessmentCard}>
          {vulnerabilityFlags.length > 0 && (
            <div className={styles.flagsPanel}>
              <h3 className={styles.flagsTitle}>Vulnerability Indicators Identified:</h3>
              <ul className={styles.flagsList}>
                {vulnerabilityFlags.map((flag, index) => (
                  <li key={index} className={styles.flagItem}>
                    {flag}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <h2 className={styles.question}>{node.question}</h2>

          <div className={styles.optionsGrid}>
            {node.options.map((option, index) => (
              <button
                key={index}
                className={styles.optionButton}
                onClick={() => handleOption(option.next, option.label, option.flag)}
              >
                {option.label}
              </button>
            ))}
          </div>

          {path.length > 1 && (
            <button className={styles.resetButton} onClick={handleReset}>
              Start New Assessment
            </button>
          )}
        </div>
      ) : (
        <div className={styles.summaryCard}>
          <h2 className={styles.summaryTitle}>Assessment Complete</h2>

          {vulnerabilityFlags.length > 0 ? (
            <>
              <div className={styles.alert}>
                <strong>VULNERABLE CUSTOMER IDENTIFIED</strong>
                <p>This customer has been identified as vulnerable. Take appropriate actions:</p>
              </div>

              <div className={styles.flagsSummary}>
                <h3 className={styles.summarySubtitle}>Documented Vulnerabilities:</h3>
                <ul className={styles.summaryList}>
                  {vulnerabilityFlags.map((flag, index) => (
                    <li key={index} className={styles.summaryItem}>
                      {flag}
                    </li>
                  ))}
                </ul>
              </div>

              <div className={styles.actions}>
                <h3 className={styles.summarySubtitle}>Required Actions:</h3>
                <ul className={styles.actionsList}>
                  <li>Flag account for special handling</li>
                  <li>Provide additional support and resources</li>
                  <li>Allow extra time for resolution</li>
                  <li>Follow up to ensure understanding</li>
                  <li>Document all interactions thoroughly</li>
                </ul>
              </div>
            </>
          ) : (
            <div className={styles.noFlags}>
              <p>No vulnerability indicators were identified during this assessment.</p>
              <p>Continue with standard service protocols.</p>
            </div>
          )}

          <button className={styles.resetButton} onClick={handleReset}>
            Start New Assessment
          </button>
        </div>
      )}
    </div>
  )
}

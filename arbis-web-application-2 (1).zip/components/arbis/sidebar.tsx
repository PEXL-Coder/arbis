"use client"

import styles from "./sidebar.module.css"

interface SidebarProps {
  activeView: string
  onNavigate: (view: string) => void
}

export default function Sidebar({ activeView, onNavigate }: SidebarProps) {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: "📊" },
    { id: "guided-flow", label: "Guided Flow", icon: "🔄" },
    { id: "knowledge-hub", label: "Knowledge Hub", icon: "📚" },
    { id: "complaints", label: "Complaints", icon: "⚠️" },
    { id: "vc-assistant", label: "VC Assistant", icon: "🤝" },
    { id: "verbatim-analyzer", label: "Verbatim Analyzer", icon: "📝" },
  ]

  return (
    <aside className={styles.sidebar}>
      <div className={styles.logo}>
        <h1>ARBIS</h1>
      </div>
      <nav className={styles.nav}>
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`${styles.navItem} ${activeView === item.id ? styles.active : ""}`}
            onClick={() => onNavigate(item.id)}
          >
            <span className={styles.icon}>{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  )
}
